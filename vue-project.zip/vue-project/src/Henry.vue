<html>
 
  <div class="whatsapp-app">
    <div class="chat-container">
      
      <div class="sidebar">
        <div class="header">
          <div class="user-profile">
            <div class="avatar">ME</div>
            <h2>Add contact</h2>
          </div>
          <div class="header-icons">
            <button class="icon-btn">
              <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="8"></circle>
                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
              </svg>
            </button>
            <button class="icon-btn">
             <a href="./src/Henry.vue"> <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
              </svg></a>
            </button>
          </div>
        </div>
       
        <h1>Add Contact</h1>
         <div class="hello">
        <input type="text">
        <input type="number"><br><br><br>
        <button type="submit">Create Contact</button>
        </div>
        <style>
        alert("Contact created")
        </style>
</html>
<style>
button{
    padding:5px;
    height: 40px;
    width:90px;
    border-radius: 10px;

}
input{
    padding:10px;
    border-radius: 10px;
    height:09px;
    width: 100px;
}
:root {
  --primary: #6C63FF;
  --secondary: #4ECDC4;
  --accent: #FF6B6B;
  --background: #F8F9FA;
  --text: #2D3436;
  --text-light: #636E72;
  --white: #FFFFFF;
  --gray-light: #DFE6E9;
  --shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
}

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', 'Helvetica Neue', sans-serif;
  color: var(--text);
}

.whatsapp-app {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: var(--background);
}

.chat-container {
  display: flex;
  width: 900px;
  height: 700px;
  background-color: var(--white);
  box-shadow: var(--shadow);
  border-radius: 16px;
  overflow: hidden;
}

/* Sidebar styles */
.sidebar {
  width: 35%;
  border-right: 1px solid var(--gray-light);
  display: flex;
  flex-direction: column;
  background-color: var(--white);
}

.header {
  padding: 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: var(--white);
}

.user-profile {
  display: flex;
  align-items: center;
  gap: 12px;
}

.header h2 {
  font-size: 20px;
  font-weight: 600;
  color: var(--text);
}

.header-icons {
  display: flex;
  gap: 12px;
}

.icon-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: var(--text-light);
  transition: all 0.2s;
  padding: 4px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
}

.icon-btn:hover {
  background-color: rgba(0, 0, 0, 0.05);
  color: var(--text);
}

.search {
  padding: 12px 20px;
  background-color: var(--white);
}

.search-container {
  position: relative;
  display: flex;
  align-items: center;
}

.search-container svg {
  position: absolute;
  left: 12px;
  color: var(--text-light);
}

.search input {
  width: 100%;
  padding: 10px 12px 10px 36px;
  border: none;
  border-radius: 8px;
  outline: none;
  background-color: #F1F3F4;
  font-size: 14px;
  transition: all 0.2s;
}

.search input:focus {
  background-color: var(--white);
  box-shadow: 0 0 0 2px var(--primary);
}

.chat-list {
  flex: 1;
  overflow-y: auto;
}

.chat-item {
  display: flex;
  padding: 14px 20px;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
}

.chat-item:hover {
  background-color: #F8F9FA;
}

.chat-item.active {
  background-color: #EFF3F4;
}

.chat-item.active::after {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  height: 100%;
  width: 3px;
  background-color: var(--primary);
}

.avatar {
  width: 48px;
  height: 48px;
  border-radius: 50%;
  color: white;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 12px;
  font-weight: bold;
  font-size: 18px;
  flex-shrink: 0;
}

.chat-info {
  flex: 1;
  min-width: 0;
}

.name-time {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 4px;
}

.name {
  font-weight: 600;
  font-size: 15px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.time {
  font-size: 12px;
  color: var(--text-light);
  flex-shrink: 0;
  margin-left: 8px;
}

.last-message {
  font-size: 13px;
  color: var(--text-light);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  display: flex;
  align-items: center;
}

.unread-badge {
  background-color: var(--primary);
  color: white;
  border-radius: 50%;
  width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  margin-right: 6px;
  flex-shrink: 0;
}

/* Chat area styles */
.chat-area {
  width: 65%;
  display: flex;
  flex-direction: column;
  background-color: #E5DDD5;
  background-image: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAYAAACNiR0NAAAABmJLR0QA/wD/AP+gvaeTAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAB3RJTUUH4AkEEjIZJ3L1JQAAAB1pVFh0Q29tbWVudAAAAAAAQ3JlYXRlZCB3aXRoIEdJTVBkLmUHAAAALUlEQVQ4y2NgGAXDADDCGEuWLPlPqQH/QcwwBooNHDVk1JBRQ0YNITRgQDEAALQzA5F6NQ8ZAAAAAElFTkSuQmCC');
}

.chat-header {
  padding: 16px 20px;
  display: flex;
  align-items: center;
  color: white;
  transition: all 0.3s;
}

.back-btn {
  display: none;
  margin-right: 12px;
  cursor: pointer;
}

.contact-info {
  display: flex;
  align-items: center;
  flex: 1;
}

.name-status {
  margin-left: 12px;
  flex: 1;
}

.name {
  font-weight: 600;
  font-size: 16px;
}

.status {
  font-size: 12px;
  opacity: 0.9;
}

.messages {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.message {
  display: flex;
  flex-direction: column;
  max-width: 70%;
  animation: fadeIn 0.3s ease-out;
}

@keyframes fadeIn {
  from { opacity: 0; transform: translateY(10px); }
  to { opacity: 1; transform: translateY(0); }
}

.message.sent {
  align-self: flex-end;
  align-items: flex-end;
}

.message.received {
  align-self: flex-start;
  align-items: flex-start;
}

.bubble {
  padding: 12px 16px;
  border-radius: 18px;
  margin-bottom: 4px;
  line-height: 1.4;
  font-size: 15px;
  word-wrap: break-word;
}

.sent .bubble {
  background-color: #DCF8C6;
  border-bottom-right-radius: 4px;
  color: #000;
}

.received .bubble {
  background-color: white;
  border-bottom-left-radius: 4px;
}

.meta {
  display: flex;
  align-items: center;
  gap: 4px;
}

.time {
  font-size: 11px;
  color: rgba(0, 0, 0, 0.45);
}

.sent .time {
  color: rgba(0, 0, 0, 0.45);
}

.received .time {
  color: rgba(255, 255, 255, 0.7);
}

.status {
  display: flex;
}

.status svg {
  width: 14px;
  height: 14px;
}

.message-input {
  padding: 12px 20px;
  display: flex;
  align-items: center;
  background-color: black;
  gap: 8px;
}

.message-input input {
  flex: 1;
  padding: 12px 16px;
  border: none;
  border-radius: 24px;
  outline: none;
  font-size: 15px;
  background-color: white;
  transition: all 0.2s;
}

.message-input input:focus {
  box-shadow: 0 0 0 2px var(--primary);
}

.emoji-btn, .attach-btn, .send-btn {
  background: none;
  border: none;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-light);
  transition: all 0.2s;
  padding: 8px;
  border-radius: 50%;
}

.emoji-btn:hover, .attach-btn:hover {
  background-color: rgba(0, 0, 0, 0.05);
  color: var(--text);
}

.send-btn {
  background-color: var(--primary);
  color: white;
}

.send-btn:hover {
  background-color: #5A52E0;
}

/* Responsive adjustments */
@media (max-width: 768px) {
  .chat-container {
    width: 100%;
    height: 100vh;
    border-radius: 0;
  }
  
  .sidebar {
    width: 100%;
    display: block;
  }
  
  .chat-area {
    width: 100%;
    display: none;
  }
  
  .chat-area.active {
    display: flex;
  }
  
  .back-btn {
    display: block;
  }
}

/* Scrollbar styling */
::-webkit-scrollbar {
  width: 6px;
}

::-webkit-scrollbar-track {
  background: rgba(0, 0, 0, 0.05);
}

::-webkit-scrollbar-thumb {
  background: rgba(0, 0, 0, 0.2);
  border-radius: 3px;
}

::-webkit-scrollbar-thumb:hover {
  background: rgba(0, 0, 0, 0.3);
}
</style>